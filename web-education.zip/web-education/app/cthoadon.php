<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cthoadon extends Model
{
    protected $table ="ct_hoa_don";
}
