<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nhantin extends Model
{
     protected $table ="nhan_tin";
}
