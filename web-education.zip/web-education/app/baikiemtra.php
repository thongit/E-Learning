<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class baikiemtra extends Model
{
     protected $table ="bai_kiem_tra";
}
