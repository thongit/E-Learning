<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class danhgiakh extends Model
{
     protected $table ="danh_gia_kh";
}
