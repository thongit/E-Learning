<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ketquakt extends Model
{
     protected $table ="ket_qua_kt";
}
