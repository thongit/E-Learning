<?php $__env->startSection( 'content'); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>
<script src="https://unpkg.com/sweetalert2@7.18.0/dist/sweetalert2.all.js"></script>

<!-- Sweet alert init js-->
<script src="<?php echo e(asset('assets/js/sweet-alerts.init.js')); ?>"></script>
<link href="<?php echo e(asset('assets/css/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" /> 
<!-- Start Login
    ============================================= -->
    <div class="login-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <form action="<?php echo e(route('xu-ly-dang-ky')); ?>" id="register-form" method="POST" class="white-popup-block">
                    <?php echo csrf_field(); ?>
                        <div class="login-custom">
                            <div class="heading">               
                                <h4><i class="fas fa-edit"></i>Đăng ký</h4>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                                    <div class="form-group">
                                        <input class="form-control" id="ho_ten" name="ho_ten" placeholder="Họ và tên*" type="text" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                               
                                    <div class="form-group">
                                        <input class="form-control" id="email" name="email" placeholder="Email*" type="email" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="form-group">
                                        <input class="form-control" id="so_cmnd" name="so_cmnd" placeholder="Số CMND*" type="number" maxlength="9" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="form-group">
                                        <input class="form-control" id="so_dt" name="so_dt" placeholder="Số điện thoại*" type="number"  maxlength="10" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="form-group">
                                        <input class="form-control" id="mat_khau" name="mat_khau" placeholder="Mật khẩu*" type="password" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="form-group">
                                        <input class="form-control" id="mat_khau_nl" name="mat_khau_nl" placeholder="Nhập lại mật khẩu*" type="password" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <button type="submit">
                                        Đăng ký
                                    </button>
                                </div>
                            </div>
                            <p class="link-bottom">Bạn đã có tài khoản? <a href="dang-nhap">Đăng nhập</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Login Area -->
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub\E-Learning\web-education\resources\views/register.blade.php ENDPATH**/ ?>